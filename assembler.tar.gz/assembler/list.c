#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#include"header.h"


void init(void){
	head1 = tail1 = NULL;
	head2 = tail2 = NULL;
}
void append(char *n, int number, int a) {
	node *head, *tail,  *temp = (node *)malloc(sizeof(node));
	temp->name = (char *)malloc(strlen(n) + 1);
	strcpy(temp->name, n);
	temp->no = number;
	temp->next = NULL;
	if(a == 0){
		head = head1;
		tail = tail1;
	}
	else{
		head = head2;
		tail = tail2;
	}
	if(head == NULL) {
		head = temp;
		tail = temp;
		if(a == 0){
			head1 = temp;
			tail1 = temp;
		}
		else{
			head2 = temp;
			tail2 = temp;
		}
	}
	else {
		tail->next = temp;
		tail = tail->next;
		if(a == 0){
			tail1 = tail;
		}
		else{
			tail2 = tail;
		}
	}
//	printf("%s %d\n", tail->name, tail->no);
}
int search(char *name, int a) {
	node *temp, *head, *tail;
	if(a == 0){
		head = head1;
		tail = tail1;
	}
	else{
		head = head2;
		tail = tail2;
	}
	temp = head;
	while(1) {
		if(!strcmp(temp->name, name)) {
			return temp->no;
		}
		if(temp->next == NULL)
			return 100;
	//	printf("%s %d\n", temp-> name, temp->no);
		temp = temp->next;
	}
}

