#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"header.h"

int main() {
	int i, j,no, k ;
	int locctr = 0, p;
	FILE *fc, *fs, *fm, *fl, *ff, *fp, *fpl, *fi;
	char name[100], n[30];
	char lb[10], st[10], op1[10], op2[10];	/*variables in which values from the file will be stored*/
	printf("Enter the name of file\n");
	scanf("%s", name);

	/*For symbols*/
	int s_cntr = 1, s_val = 0, s_arr[20];
	char s_str[20][8];

	/*For Literals*/
	char l_str[20][5];
	int litcntr = 1, plitcntr = 1;

	/* fc is pointer to the source code*/
	fc = fopen(name, "r");
	if(fc == NULL){
		printf("File %s not found\n", name);
		return 0;
	}
	/* fs is pointer to the symbol table*/
	fs = fopen("symtab", "w+");
	if(fs == NULL){
		printf("File %s not found\n", "symtab");
		return 0;
	}
	/* fi is pointer to the intermediate table*/
	fi = fopen("intermediate", "w+");
	if(fi == NULL){
		printf("File %s not found\n", "intermediate");
		return 0;
	}
	/* fl is pointer to the literal table*/
	fl = fopen("littab", "w+");
	if(fl == NULL){
		printf("File %s not found\n", "littab");
		return 0;
	}
	/* fpl is pointer to the pool table*/
	fpl = fopen("pooltab", "w+");
	if(fpl == NULL){
		printf("File %s not found\n", "pooltab");
		return 0;
	}
	/*For imperative statements*/
	fp = fopen("optab", "r");
	if(fp == NULL){
		printf("File %s not found\n", name);
		return 0;
	}
	init();
	while(1){
		/*taking all the opcodes and saving in the link list*/
		fscanf(fp, "%s%d", n, &no);
		if(feof(fp)){
			fclose(fp);
			break;
		}
		append(n, no, 0);
	}

	/*For assembler directive*/
	fp = fopen("ad", "r");
	if(fp == NULL){
		printf("File %s not found\n", name);
		return 0;
	}
	while(1){
		/*taking all the assembler directives and saving in the link list*/
		fscanf(fp, "%s%d", n, &no);
		if(feof(fp)){
			fclose(fp);
			break;
		}
		append(n, no, 1);
	}

	fscanf(fc, "%s%s%s%s", lb, st, op1, op2);/*Scanning from a file*/

	if(strcmp(st, "START") == 0){
		if(strcmp(op1, "-") != 0)
			locctr = atoi(op1);
		fprintf(fi, "%d\t%s\t%s\t%s\t%s\t\tAD 0\t\tc %d\t\t- -\n", locctr, lb, st, op1, op2, locctr);
	}
	else{
		printf("Error: START not found\n");
		exit(0);
	}
	locctr++;

	/* The main while loop */

	while(!feof(fc)) {
		no = 100; /* default value*/
		fscanf(fc, "%s%s%s%s", lb, st, op1, op2);/*Scanning from a file*/

		if(strcmp(lb, "-") != 0){		/*Entering the symbols in symbol table*/
			for(i =0; i < s_cntr; i++){
				if(!strcmp(s_str[i], lb))
					break;
			}
			if(i == s_cntr){
				fprintf(fs, "%s\t%d\n", lb, locctr);
				strcpy(s_str[s_cntr], lb);
				s_cntr++;
			}
			i = 0;
		}

		if(strcmp(st, "LTORG") == 0){
			fprintf(fi, "%d\t%s\t%s\t%s\t%s\t\tAD 20\t\t- -\t\t- -\n", locctr, lb, st, op1, op2);
			locctr++;
			for(p = 1; p < plitcntr; p++){
				fprintf(fl, "%s\t%d\n", l_str[p], locctr);
				fprintf(fi, "%d\t-\t%s\t-\t-\t\t- -\t\t- -\t\t- -\n", locctr, l_str[p]);
				locctr++;
			}
			plitcntr = 1;
			fprintf(fpl, "%d\n", litcntr);
			continue;
			/*Literal table will be used*/
		}

		/*Declarative Statements*/
		if(strcmp(st, "DS") == 0){
			fprintf(fi, "%d\t%s\t%s\t%s\t%s\t\tDL 23\t\tc %s\t\t- -\n", locctr, lb, st, op1, op2, op1);
		}
		if(strcmp(st, "DC") == 0){
			fprintf(fi, "%d\t%s\t%s\t%s\t%s\t\tDL 24\t\tc %s\t\t- -\n", locctr, lb, st, op1, op2, op1);
		}

		if(strcmp(st, "END") == 0){
			fprintf(fi, "%d\t%s\t%s\t%s\t%s\t\tAD 1\t\t- -\t\t- -\n", locctr, lb, st, op1, op2);
			locctr++;
			for(p = 1; p < plitcntr; p++){
				fprintf(fl, "%s\t%d\n", l_str[p], locctr);
				fprintf(fi, "%d\t-\t%s\t-\t-\t\t- -\t\t- -\t\t- -\n", locctr, l_str[p]);
				locctr++;
			}
			fprintf(fpl, "%d\n", litcntr);
			printf("Ending Address of program is %d\n", locctr - 1);
			break;
		}

		/*For Imperative statements and assembler directives*/
		no = 100;
		no = search(st, 0);
		k = 0;
		k = strcmp(op2, "-");
		if(no != 100){
			i = strcmp(op1, "AREG");
			i++;
			if(strncmp(op2, "=", 1) == 0){
				fprintf(fi, "%d\t%s\t%s\t%s\t%s\t\tIS %d\t\t%d -\t\tL %d\n", locctr, lb, st, op1, op2, no, i, litcntr);
				strcpy(l_str[plitcntr], op2);
				litcntr++;
				plitcntr++;
			}
			else{
				if(k == 0 && (i < 0 || (i > 3))){
					for(p = 0; p < s_cntr; p++){
						if(!strcmp(s_str[p], op1))
							break;
					}
					fprintf(fi, "%d\t%s\t%s\t%s\t%s\t\tIS %d\t\tS %d\t\t- -\n", locctr, lb, st, op1, op2, no, p);
				}
				else if(k ==0)
					fprintf(fi, "%d\t%s\t%s\t%s\t%s\t\tIS %d\t\t%d -\t\t- -\n", locctr, lb, st, op1, op2, no, i);
				else
					fprintf(fi, "%d\t%s\t%s\t%s\t%s\t\tIS %d\t\t%d -\t\tc %s\n", locctr, lb, st, op1, op2, no, i, op2);
			}
		}
		no = 100;
		no = search(st, 1);
		if(no != 100){
			fprintf(fi, "%d\t%s\t%s\t%s\t%s\t\tAD %d\t\tc %s\t\t- -\n", locctr, lb, st, op1, op2, no, op1);
		}

		locctr++;
	}
	return 0;
}
