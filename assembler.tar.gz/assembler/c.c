#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"header.h"

int main() {
	int i, j,no, k ;
        char c[20], a[20], b[20], d[20], e[20];
        FILE *fp, *fw;
        fp = fopen("intermediate", "r+");
        if(fp == NULL)
                return 0;
        i = fscanf(fp, "%*s%*s%*s%*s%*s%s%s%s%s%s\n", a, b, c, d, e);
        printf("\n%d\n%s\t%s\t%s\t%s\t%s\n",i,  a, b, c, d, e);
        return 0;
}
