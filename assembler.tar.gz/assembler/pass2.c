#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"header.h"

int main() {

        int i, j,no, k;
        int locctr = 0, p;
        char a[7], b[7], c[7], d[7], e[7], f[7], cntr[6];
        FILE *fs, *fl, *fo, *fi, fp;
        /* fs is pointer to the symbol table*/
        fs = fopen("symtab", "r+");
        if(fs == NULL){
                printf("File %s not found\n", "symtab");
                return 0;
        }
        /* fi is pointer to the intermediate table*/
        fi = fopen("intermediate", "r+");
        if(fi == NULL){
                printf("File %s not found\n", "intermediate");
                return 0;
        }
        /* fl is pointer to the literal table*/
        fl = fopen("littab", "r+");
        if(fl == NULL){
                printf("File %s not found\n", "littab");
                return 0;
        }
        /* fo is output*/
        fo = fopen("output", "w");
        if(fo == NULL){
                printf("File %s not found\n", "output");
                return 0;
        }
        while(!feof(fi)){
                fscanf(fi, "%s%s%s%s%s",cntr,  a, b, c, d);
                fprintf(fo, "%s\t%s\t%s\t%s\t%s\t", cntr, a,b, c, d);
                fscanf(fi, "%s%s%s%s%s%s",  a, b, c, d, e, f);
                if(strcmp(b, "-"))
                        fprintf(fo, "%s\t", b);
                if((c[0] -'0' < 10) && (c[0] - '0' >= 0) ){
                        fprintf(fo, "%s\t", c);
                }
                else{
                        if(!strcmp(c, "S")){
                                no = atoi(d);
                                for(i = 1; i <= no; i++){
                                        fscanf(fs, "%*s%d", &p);
                                }
                                rewind(fs);
                                fprintf(fo, "%d\t", p);
                        }
                        else if(!strcmp(c, "c")){
                                fprintf(fo, "%s\t", d);
                        }
                }
                if(!strcmp(e, "S")){
                        no = atoi(f);
                        for(i = 1; i <= no; i++){
                                fscanf(fs, "%*s%d", &p);
                        }
                        rewind(fs);
                        fprintf(fo, "%d\t", p);
                }
                else if(!strcmp(e, "L")){
                        no = atoi(f);
                        for(i = 1; i <= no; i++){
                                fscanf(fl, "%*s%d", &p);
                        }
                        rewind(fl);
                        fprintf(fo, "%d\t", p);
                }
                else if(!strcmp(e, "c")){
                        fprintf(fo, "%s\t", f);
                }
                        fprintf(fo, "\n");
        }
        fclose(fo);
        fclose(fs);
        fclose(fl);
        return 0;
}
