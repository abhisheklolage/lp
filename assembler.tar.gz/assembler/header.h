typedef struct node{
	 int no;
	char *name;
	struct node *next;
}node;
node *head1, *tail1, *head2, *tail2;
void init(void);
void append(char *, int, int);
int search(char *, int);
