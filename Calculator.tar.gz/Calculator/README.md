# Calculator
Lex/Yacc Calculator
A simple Lex/Yacc calculator. Can store expressions in variables using the syntax, variable=expression, where variable is the name (string characters only) of the variable and the expression is the value.
