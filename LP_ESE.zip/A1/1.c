/*
Write a program to give the line numbers to every line in the text file
and give the no. of words exists per line
*/

/*
	Open file in read-write mode
	Copy all content of the file into an array

	Loop (till end-1 of an array) {
		check for word {
			if previous character is not in [',' , '.' , ' ', ';', ':', '?', '/', '\t', '\n', 'EOF'] an current positin is non-zero
			then only increment the wordcount
			i.e wordcnt++
		}
		check for line 
			linecnt++

		write the current character into the opened file
		if it is \n then write the current [<line count>. ]
	}
	close file
*/

#include <stdio.h>
#include <stdlib.h>

#define MAX 2048
#define WORDCHECK(x) (x == ' ' || x == ',' || x == ';' || x == '\n' || x == '\t' || x == ':' || x == '.' || x == '?' || x == EOF)
int main(int argc, char *argv[]) {
	int i, j, lc, wc, ret;
	char a[MAX], c;
	FILE *fp;

	fp = fopen(argv[1], "r");

	for (i = 0; (ret = (fscanf(fp, "%c", &c))) != EOF; i++) {
		a[i] = c;
	}
	fclose(fp);

	fp = fopen(argv[1], "w");
	if (i == 0)
		return -1;
	
	lc = 1;
	wc = 0;
	fprintf(fp, "1. ");
	for (j = 0; j < i-1; j++) {
		if (j && WORDCHECK(a[j]) && !WORDCHECK(a[j-1]))
			wc++;
		fprintf(fp,"%c", a[j]);
		if (a[j] == '\n') {
			wc = 0;
			fprintf(fp, "%d. ", ++lc);	
		}
	}
	if (!WORDCHECK(a[j-1]))
		wc++;
	fputc('\n', fp);
	fclose(fp);

	printf("%d  %d  %s\n", lc, wc, argv[1]);
	return 0;
}
