#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>

#define BUFFER_SIZE 1024
#define TOKEN_SIZE 32
#define TRUE 1
#define FALSE 0

int isKeyword(const char* token)
{
        int i;
        const char keywords[32][20]={"auto","break","case","char",
                "const","continue","default","do","double",
                "else","enum","extern","float",
                "for","goto","if","int","long",
                "register","return","short","signed",
                "sizeof","static","struct","switch",
                "typedef","union","unsigned",
                "void","volatile","while"};
        for(i=0;i<32;i++)
        {
                if(strcmp(token,keywords[i])==0)
                        return TRUE;
        }
        return FALSE;
}

int isIntLiteral(const char* token)
{
        int i;
        for(i=0;token[i]!='\0';i++)
        {
                if(!isdigit(token[i]))
                        return FALSE;
        }
        return TRUE;
}

int isFloatLiteral(const char* token)
{       int i;
        if(isdigit(token[0]))
        {
                for(i=1;token[i]!='\0';i++)
                {
                        if(!isdigit(token[i]) && (token[i])!='.')
                                return FALSE;
                }
                return TRUE;
        }
        return FALSE;
}

int isCharLiteral(const char* token)
{
        if(token[0]=='\'' && strlen(token)==3 && token[2]=='\'')
                return TRUE;
        else
                return FALSE;
}

int isLiteral(const char* token)
{
        if(isCharLiteral(token)||isIntLiteral(token)||isFloatLiteral(token))
                return TRUE;
        else
                return FALSE;
}

int isIdentifier(const char* token)
{
        int i;
        if(isalpha(token[0]) || token[0]=='_')
        {
                for(i=1;token[i]!='\0';i++)
                {
                        if(!isalnum(token[i]))
                                return FALSE;
                }
                return TRUE;
        }
        return FALSE;
}

int isOperator(const char* token)
{
        int i;
        const char operators[41][10] = {".","->","++","--","!","~","(type)","*","&",
                "sizeof","*","/","%","+","-","<<",">>","<",
                "<=",">",">=","==","!=","&","^","|","&&","||",
                "?:","=","+=","-=","*=","/=","%=","&=","^=",
                "|=","<<=",">>=",","};

        for(i=0;i<41;i++)
        {
                if(strcmp(token,operators[i])==0)
                        return TRUE;
        }
        return FALSE;
}

FILE * readFile(int param1,char* param2[])
{
        if(param1<2)
        {
                fprintf(stderr,"No file specifed to read. \n");
                exit(1);
        }

        if(param1>2)
        {
                fprintf(stderr,"Too many arguments for read to perform. \n");
                exit(1);
        }

        FILE *fp = fopen(param2[1],"r");

        if(!fp)
        {
                fprintf(stderr,"File access denied on read. \n");
                exit(1);
        }
        return fp;
}

int main(int argc,char* argv[])
{

        FILE *fp = readFile(argc,argv);

        char *token;
        char string[BUFFER_SIZE];
        const char delimiters[]=" ,;\n\t";

        fgets(string,sizeof string, fp);
        while(string!=(char *)NULL || (strcmp(string,"\n"))==0)
        {
                token = strtok(string,delimiters);

                while(token!=NULL)
                {
                        if(isKeyword(token))
                                printf("%10s\t\t: Keyword\n",token);
                        else if(isOperator(token))
                                printf("%10s\t\t: Operator\n",token);
                        else if(isIdentifier(token))
                                printf("%10s\t\t: Identifier\n",token);
                        else if(isLiteral(token))
                                printf("%10s\t\t: Literal\n",token);
                        else{
                                if (token[strlen(token)-1] == ')')
                                    printf("%10s\t\t: Function\n",token);
                                else if(token[0] == '{')
                                    printf("%10s\t\t: Left(opening) Curly Brace\n",token);
                                else if(token[0] == '}')
                                    printf("%10s\t\t: Right(closing) Curly Brace\n",token);
                                else if(token[0] == '#')
                                    printf("%10s\t: Preprocessor statement\n",token);
                                else
                                    printf("%10s\t\t: Unknown/Unrecognized\n", token);
                              //  exit(0);
                        }

                        token = strtok(NULL,delimiters);
                }
                if(fgets(string,sizeof(string), fp) == NULL)
                        break;
        }

        fclose(fp);
        return 0;
}
