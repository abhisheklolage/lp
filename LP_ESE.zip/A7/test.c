#include<stdio.h>
int main() {
        int i, j;
        printf("Hello");
        All is Well
        return;
}
