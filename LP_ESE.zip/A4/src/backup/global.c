#include "global.h"
int location_counter;   // To track the instruction address

char *optab[] = {
         // ASSUME THAT  INSTRUCTION LENGTH IS 1 AS PER THE OBSERVATION
         // ENTRIES FOR 'IMPERATIVE STMT', OPCODE = index 
          "STOP",
	  "ADD",
	  "SUB",
	  "MULT",
	  "MOVEM",
          "MOVER",
	  "COMP", 
	  "BC",  
	  "DIV", 
	  "READ",
	  "PRINT",

	 // ENTRIES FOR 'ASSEMBLER DIRECTIVE', OPCODE = index - 10
	  "START",
	  "END",
	  "ORIGIN",
	  "EQU",   
	  "LTORG", 

	 // ENTRIES FOR 'DECLARATIVE STMT', OPCODE = index - 15
	  "DS",
	  "DC",
};


char *reg[] = {"AREG", "BREG", "CREG", "DREG"};


symtable symbol[1024];
unsigned int symtab_counter;

littable littab[1024];
unsigned int littab_counter;

unsigned char pooltab_counter;
