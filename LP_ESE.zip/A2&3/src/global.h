#ifndef GLOBAL_H
#define GLOBAL_H

// symbol table
typedef struct symbol {
  char label[16]; // symbol name for the fwd reference
  int address;    // value for particular symbol
                  // ASSUME THAT  INSTRUCTION LENGTH IS 1 AS PER THE OBSERVATION
}symtable;

// literal table
typedef struct literal {
  int literal; // literal value
  int address; // literal address by using the location counter
}littable;
#endif
