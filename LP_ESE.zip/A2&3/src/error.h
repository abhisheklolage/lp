void pError(char *);
char eStart;// flag used for START instruction
