#include <stdio.h>
#include <stdlib.h>

void pError(char *error) {
  printf("error:%s", error);
  exit(-1);
}
