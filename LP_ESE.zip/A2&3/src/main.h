#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "global.h"
#include "error.h"

#define PASS_ONE_OUTPUT
#define PASS_TWO_OUTPUT

#define LABEL       0
#define INSTRUCTION 1
#define OPERAND     2


// Max Numbers for Opcodes, Imperative Statement, Assembler Directive, Declarative Statement
#define MAX_OP 17
#define MAX_IM 10
#define MAX_AD 5
#define MAX_DL 2


// Errors definition II => invalid instruction
// Error value 0 means successful execution
#define ERROR          -1
#define II_EXOP         1
#define II_INSTRUCION   2
#define II_COMMENT      3
// Values of the Instruction
#define I_BC            7

#define SIZE_LTORG 1
#define SIZE_DL    1
#define SIZE_AD    1
#define SIZE_IM    1

#define NO_ADDRESS -1
#define MAX_REG     4

extern int location_counter;

extern char *optab[];
extern char *reg[];

extern symtable symbol[1024];
extern unsigned char symtab_counter;

extern littable littab[1024];
extern unsigned char littab_counter;

extern unsigned char pooltab_counter;

//tool.c includes following
char *strupr(char *);
char fileopen(FILE **, FILE **, char *);

//search.c includes following
void insert_into_symtab(char *, int );
char check_category(char *, char );
char read_split_fill(FILE *, char *, char *, char *, char *);
char isregister(char *);
char search_or_insert_label(char *);

//insert.c includes following
void insert_into_symtab(char *, int );
void insert_into_littab(int , int );
void insert_into_pooltab(unsigned char );
void write_pooltab(char *);
void write_symtab(char *);
void write_littab(char *);

//main.c 
char pass_one(FILE *, FILE *);
char pass_two(FILE *, FILE *);
#endif
