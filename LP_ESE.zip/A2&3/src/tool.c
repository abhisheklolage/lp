#include "main.h"
#include <ctype.h>

char *strupr(char *string) {
  char *tmp;
  tmp = string;
  while((*string = toupper(*string))) {
    string++;
  }

  return tmp;
}

// Opens the file as per requirement
char fileopen(FILE **fp1, FILE **fp2, char *filename) {
  #define FILE_OPEN_ERROR 1

  char icfile[16];
  
  if ((*fp1 = fopen(filename, "r")) == NULL)
    return FILE_OPEN_ERROR;
  sprintf(icfile, ".%s.i", filename);
  if ((*fp2 = fopen(icfile, "w")) == NULL)
    return FILE_OPEN_ERROR;
  return 0;
}


// Reads the instruction line by line and checks for the standard format of the instruction
char read_split_fill(FILE *asmfile, char *label, char *instruction, char *operand1, char *operand2) {
  #define MAX_STMT_LEN 128

  char index, buffer[MAX_STMT_LEN], ch, prev_ch, ret;
  int i;

  ret = 0;
  index = 0;
  i = 0;
  prev_ch = ' ';
  label[0] = '\0';
  instruction[0] = '\0';
  operand1[0] = '\0';
  operand2[0] = '\0';

  while(1) {
    ch = fgetc(asmfile);
    if (!((prev_ch ^ ' ' && prev_ch ^ ',' && prev_ch ^ '\n') || (ch ^ ' ' && ch ^ '\n' && ch ^ ',')) || !(i ^ -1)) {
      if (!(ch ^ '\n')) {
	    break;
      }
      continue;
    }
    prev_ch = ch;
    if (!((ch ^ ' ') && (ch ^ ',') &&  (ch ^ '\n') && (ch ^ EOF) && (ch ^ '#'))) {
        buffer[i] = '\0';
  	    if (!((ch ^ '#') || index || i)) {
	      i = -1;
	      ret = II_COMMENT;
	      continue;
	    }
	    else if (!((ch ^ '#') || i)) {
	      i = -1;
	      continue;
	    }
	  

	switch(check_category(buffer, index)) {
  	  case LABEL:
        strcpy(label, buffer);
	    break;
	  case INSTRUCTION:
	    if (!label[0])
	      index++;
        strcpy(instruction, buffer);
	    break;
	  case OPERAND:
        strcpy(operand1, buffer);    
        break;
	  case OPERAND+1:
	    strcpy(operand2, buffer);
	    break;
	  default:
	    printf("Error occurred : Invalid symbol\n");
	    break;
        }

	if (!(ch ^ '#')) {
	  i = -1;
	  continue;
	}
    // return error_check(label, instruction, operand1, operand2, index)  complete it
    if(!(ch ^ EOF)) {
	  return EOF;
	}
	else if(!(ch ^ '\n'))
	  break;

        i = 0;
        index++;
	
    }
    else  {
      buffer[i++] = ch;
    }
  } 
 
  return ret;
}

void write_pooltab(char *filename) {
  FILE *fp = fopen(filename, "w");
  char i;

  for (i = 0; i < sizeof(char)*8; i++) {
    if(pooltab_counter>>i & 1)
      fprintf(fp, "#%d\n", i);
  }
  fclose(fp); 
}

void write_littab(char *filename) {
  FILE *fp = fopen(filename, "w");
  int i;

  for(i = 0; i < littab_counter; i++)
    fprintf(fp, "%-5d %5d\n", littab[i].literal, littab[i].address);
  fclose(fp); 
}

void write_symbol(char *filename) {
  FILE *fp = fopen(filename, "w");
  int i;

  for (i = 0; i < symtab_counter; i++)
    fprintf(fp, "%-10s %5d\n", symbol[i].label, symbol[i].address);
  fclose(fp); 
}
