#include "main.h"

void insert_into_symtab(char *label, int address) {
  int i;

  for (i = 0; i < symtab_counter; i++) {
    if (!strcmp(symbol[i].label, label)) {
      if (symbol[i].address == NO_ADDRESS)
	break;
      else {
	// error_generator("Duplicate Reference");	
	return;
        // return error more than one times reference or ambigous label since repeated
      }
    }

  }
  strcpy(symbol[i].label, label);
  symbol[i].address = address;
  symtab_counter++;
}
void insert_into_littab(int literal, int address) {
  int i;

  for (i = 0; i < littab_counter; i++) {
    if (littab[i].literal == literal) {
      if (littab[i].address == NO_ADDRESS)
	break;
      else;
      //call the error function double reference
    }
  }
  littab[i].literal = literal;
  littab[i].address = address;
  littab_counter++;
}

void insert_into_pooltab(unsigned char val) {
  pooltab_counter |= (1<<val);
}
