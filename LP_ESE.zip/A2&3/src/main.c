#include "main.h"

char pass_one(FILE *asmfile, FILE *icfile) {
  char label[16], instruction[16], operand1[16], operand2[16], opcode, reg, ret;
  int count;

  ret = 0;
  symtab_counter = 0;
  littab_counter = 0;
  pooltab_counter = 0;
  while((ret = read_split_fill(asmfile, label, instruction, operand1, operand2)) != EOF) {
    if ((ret == II_COMMENT) || !(instruction[0] || operand1[0] || operand2[0] || label[0]))//Handle comment
      continue;
    printf(">> L:%-10s I:%-10s O:%-5s O:%-5s\n", label, instruction, operand1, operand2);
    if (label[0] && label[0] ^ '=' && (strcmp(strupr(instruction), "EQU"))) {
      //insert label and addr
      insert_into_symtab(label, location_counter);
    }
    if (!strcmp(strupr(instruction), "LTORG")) {
      fprintf(icfile, "%5.3d (AD,05)\n", location_counter);
      insert_into_pooltab(littab_counter);
    }
    else if (!(label[0] ^ '=')) {//Handling of the LTORG and END statement literals
      //insert into literal table
      insert_into_littab(atoi(&label[2]), location_counter);
      location_counter += SIZE_LTORG;
    }
    else if (!strcmp(strupr(instruction), "START")) {
      if (eStart)
        pError("Double START");
      eStart = 1;
      //handle error of the double start stmt by adding the flag 
      //initialize the location counter
      if (operand1[0])
        location_counter = atoi(operand1);
      else
        pError("Operand Missing at START");
	//call error function

      fprintf(icfile, "  --- (AD,01) (C,%03d) \n", location_counter);
    }
    else if(!strcmp(strupr(instruction), "EQU")) {
      //assign value to label
      if (operand1[0] && !isdigit(operand1[0])) {
        insert_into_symtab(label, -1);
        insert_into_symtab(operand1, -1);
      }
      else if (operand1[0]) //if operand is not a symbol  
	      insert_into_symtab(label, atoi(operand1));
      else
        pError("Operand Missing at EQU");
	  //call error function

      location_counter += SIZE_AD;
    }
    else if ((opcode=search_optab(strupr(instruction))) < MAX_IM) {
      //imperative stmt handle accordingly
      fprintf(icfile, "%5.3d (IS,%2.2d) ", location_counter, opcode);
      if (operand1[0]) {
	 if (opcode == I_BC) {
	   fprintf(icfile, "(%d) ", search_bc(strupr(operand1)));//handle error by return value
	 }
	 else if ((reg = isregister(strupr(operand1)))) {
	   fprintf(icfile, "(%d) ", reg);
	 }
	 else if (!(operand1[0] ^ '=')) {
	   fprintf(icfile, "(L,%03d) ", ++littab_counter);
	   insert_into_littab(atoi(&operand1[2]), NO_ADDRESS);
	 }
	 //else if ((count = search_or_insert_label(strupr(operand1)))) {
	 else if (1 || (count = search_or_insert_label(operand1))) {
	   fprintf(icfile, "(S,%03d) ", count);
	 }
	 else {
            pError("Invalid Syntax\n");
         }
	 //call error function
      }
      if (operand2[0]) {
	 if (!(operand2[0] ^ '=')) {
	   fprintf(icfile, "(L,%03d) ", atoi(&operand2[2]));
	 }
	 else if ((count = search_or_insert_label(strupr(operand2)))) {
	   fprintf(icfile, "(S,%03d) ", count);
	 }
	 else;
	 //call error function
      }
      fprintf(icfile, "\n");
      // check error for every other instruction
      location_counter += SIZE_IM;
    }
    else if ((opcode=search_optab(strupr(instruction))) > (MAX_IM+MAX_AD-1)) {
       //declarative stmt handle accordingly
       if (operand1[0]) {
           fprintf(icfile, "%5.3d (DL,%2.2d) (C,%03d) \n", location_counter, (opcode-15), atoi(operand1));
       }
       else;
       //call error function
       location_counter += SIZE_DL;
    }
    else if (!strcmp(strupr(instruction), "END")) {
      fprintf(icfile, "%5.3d (AD,02) \n", location_counter);
      insert_into_pooltab(littab_counter);
    }
    
  }
  write_pooltab("pooltable");
  write_littab("literaltable");
  write_symbol("symboltable");
  return 0;
}

char pass_two(FILE *icfile, FILE *pass_two_op) {
  int i;
  char s[16];

  while(1) {
    fprintf(pass_two_op, "\n");
    if (fscanf(icfile, "%s", s) == EOF)
      return 0;

    i = 1;

    fprintf(pass_two_op, "%5.3d ", atoi(s));
    fscanf(icfile, "%s", s);

    fprintf(pass_two_op, "+%02d ", atoi(&s[4]));
    
    while(i--) {
      if(fscanf(icfile, "%s", s) == EOF)
	return 0;

      if (s[2] == ')') {
	fprintf(pass_two_op, "00%c", s[1]);
    continue;
      }

      switch(s[1]) {
      case 'S':
	fprintf(pass_two_op, "%03d ", symbol[atoi(&s[4])].address);
	break;
      case 'L':
      case 'C':
	fprintf(pass_two_op, "%03d ", atoi(&s[4]));
	break;
      }
    }
    
  }
}

int main(int argc, char *argv[]) {
  char cmd[64], filename[64];
  FILE *asmfile, *icfile, *pass_two_op;

  if (fileopen(&asmfile, &icfile, argv[1]))
    printf("File Error : Invalid Input file\n");

  if (pass_one(asmfile, icfile))
    printf("Error occurred : Pass One Error\n");

  fcloseall();

#ifdef PASS_ONE_OUTPUT
  printf("\nOUTPUT OF THE PASS-1 :\n");
  sprintf(cmd, "cat .%s.i", argv[1]); //creating cmd to o/p 
  system(cmd);
#endif
  sprintf(filename, ".%s.i", argv[1]); //creating cmd to o/p   
  icfile = fopen(filename, "r");
  sprintf(filename, "%s.obj", argv[1]); //creating cmd to o/p   
  pass_two_op = fopen(filename, "w");
  if (pass_two(icfile, pass_two_op))
    printf("Error occurred\n");
  fcloseall();
#ifdef PASS_TWO_OUTPUT
  printf("\nOUTPUT OF THE PASS-2 :\n");
  sprintf(cmd, "cat %s.obj", argv[1]); //creating cmd to o/p 
  system(cmd);
#endif 
  printf("\n\n");
  return 0;
}
